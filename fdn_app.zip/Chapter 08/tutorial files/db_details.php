<?php

$username = "root";
$password = "";
$database = "flashblog";
$hostname = "localhost";

?>
